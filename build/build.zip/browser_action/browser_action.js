"use strict";!function(){var e=chrome.extension.getBackgroundPage(),n=e.WeShareOp;n.browserAction(window,function(){}),document.querySelector("#wso-amundiAccess").addEventListener("click",function(){n.openNewAmundiTab()})}();
//# sourceMappingURL=browser_action.js.map
